package com.example.vanessa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class tela_admin extends AppCompatActivity {
    EditText login, senha;
    CheckBox adm;
    static ArrayList<usuário> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_admin);
        login = findViewById(R.id.loginadmin);
        senha = findViewById(R.id.senhaadmin);
        adm = findViewById(R.id.checkadmin);
    }

    public void cadastro(View c){
        String l = login.getText().toString();
        String s = senha.getText().toString();
        if(adm.isChecked()){
            usuário u = new usuário(l,s,2);
        }
        else{
            usuário u = new usuário(l,s,1);
            list.add(u);
        }
        Toast.makeText(this, "usuário cadastrado!", Toast.LENGTH_LONG).show();

    }
}