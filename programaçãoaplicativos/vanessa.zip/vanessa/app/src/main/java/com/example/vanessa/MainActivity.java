package com.example.vanessa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText campo, senha;
    TextView exibe;
    ArrayList<usuário> usu = new ArrayList<>();
    usuário encontrado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        campo = findViewById(R.id.nome);
        exibe = findViewById(R.id.t);
        senha = findViewById(R.id.senha);
        usuário u = new usuário("vanessa", "12345", 1);
        usuário a = new usuário("alice", "senha", 2);
        usu.add(u);
        usu.add(a);

    }

    public void clica(View c) {
        if (verificarusuario(campo.getText().toString(), senha.getText().toString())) {
            String texto = campo.getText().toString();
            Toast.makeText(this, "bem vindo, " + texto, Toast.LENGTH_SHORT).show();
            exibe.setText(texto);
            campo.setText(null);
            if (encontrado.perfil == 1) {
                mudaTela();

            } else if (encontrado.perfil == 2) {
                tela_admin.list = usu;
                mudaTelaadmin();
            }


    } else {

        Toast.makeText(this, "usuário ou senha inválida!", Toast.LENGTH_SHORT).show();
    }

}
    public void mudaTelaadmin(){

        Intent z = new Intent(this, tela_admin.class);
        startActivity(z);
}
    public void mudaTela(){

        Intent i = new Intent(this, tela1.class);
        startActivity(i);

    }

    public boolean verificarusuario(String login, String senha){
        for(usuário pessoa:usu){
        if(login.equals(pessoa.login) && senha.equals(pessoa.senha)){
            encontrado = pessoa;
            return true;

        }
        }

        return false;

    }
}