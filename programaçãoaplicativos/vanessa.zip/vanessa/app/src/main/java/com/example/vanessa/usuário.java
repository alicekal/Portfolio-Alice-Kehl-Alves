package com.example.vanessa;

public class usuário {
    String login, senha;
    int perfil;

    public usuário(String login, String senha) {
        this.login = login;
        this.senha = senha;
    }

    public usuário(String login, String senha, int perfil) {
        this.login = login;
        this.senha = senha;
        this.perfil = perfil;

    }
}
