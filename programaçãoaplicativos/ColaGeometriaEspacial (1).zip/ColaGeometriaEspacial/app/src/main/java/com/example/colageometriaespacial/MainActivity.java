package com.example.colageometriaespacial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton at, abat, abv, nl, af, v, a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        at = findViewById(R.id.at);
        abat = findViewById(R.id.abat);
        abv = findViewById(R.id.abv);
        nl = findViewById(R.id.nl);
        af = findViewById(R.id.af);
        v = findViewById(R.id.v);
        a = findViewById(R.id.a);
    }
    public void click(View view){
        Intent i = new Intent(this, TelaCalculo.class);

        if(at.isChecked()){
            TelaCalculo.formula = 1;
            startActivity(i);
        }

        else if(abat.isChecked()){
            TelaCalculo.formula = 2;
            startActivity(i);
        }

        else if(abv.isChecked()){
            TelaCalculo.formula = 3;
            startActivity(i);
        }

        else if(nl.isChecked()){
            TelaCalculo.formula = 4;
            startActivity(i);

        }
        else if(af.isChecked()){
            TelaCalculo.formula = 5;
            startActivity(i);

        }
        else if(v.isChecked()){
            TelaCalculo.formula = 6;
            startActivity(i);

        }
        else if(a.isChecked()){
            TelaCalculo.formula = 7;
            startActivity(i);

        }
        else{
            Toast.makeText(this, "Você precisa relacionar uma opção!", Toast.LENGTH_LONG).show();
        }
    }
}